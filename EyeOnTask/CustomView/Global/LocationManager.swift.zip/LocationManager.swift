//
//  LocationManager.swift
//  EyeOnTask
//
//  Created by Hemant Pandagre on 25/07/18.
//  Copyright © 2018 Lokesh. All rights reserved.
//

import UIKit
import CoreLocation
import GLKit

class LocationManager: NSObject , CLLocationManagerDelegate {
    
    static let shared = LocationManager()
    let locationManager = CLLocationManager()
    
    var centreLocation = CLLocation()
    var locationHistory = [CLLocation]()
    var isUpdate = true
    //var isLocation = Bool()
    var isFirstLocation: Bool = true
    var Currentloc = CLLocation()
    var oldLocation = CLLocation()
    var currentLattitude : String = "0.0"
    var currentLongitude : String = "0.0"
    var isPermissionAsked = Bool()
    var isFirstTime : Bool = true
    var isStatus : Bool = false
    var isFirstLogin : Bool = true
    var  isGPSenable = false
    var bgTask : BackgroundTaskManager?
    var timer : Timer?
    var statusTimer : Timer?
    var userDistance : Int = 0
    var isBackgroundMode = false
    
    var callback: ((Bool) -> Void)?
    
    
    private override init() {
        super.init()
        
        locationManager.delegate = self
        locationManager.allowsBackgroundLocationUpdates = true
        locationManager.pausesLocationUpdatesAutomatically = false
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        //  locationManager.distanceFilter = kCLDistanceFilterNone
        
        if #available(iOS 11.0, *) {
            locationManager.showsBackgroundLocationIndicator = true
        } else {
            // Fallback on earlier versions
        }
        
        locationManager.requestAlwaysAuthorization()
        // print("initialize Location Manager")
    }
    
    
    //========================================================
    // MARK:- Notification Registration
    //========================================================
    func setNotificationCentreForlocation() -> Void {
        NotificationCenter.default.addObserver(self, selector: #selector(self.enterInBackgroundMode(notification:)), name: UIApplication.didEnterBackgroundNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.enterInForegroundMode(notification:)), name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    
    func removeNotificationCentreForlocation() -> Void {
        NotificationCenter.default.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
    }
    
    
    //========================================================
    // MARK:- Background enter and Foreground method
    //========================================================
    @objc func enterInBackgroundMode(notification: NSNotification) {
        isUpdate = true
        isBackgroundMode = true
        locationManager.startUpdatingLocation()
    }
    
    @objc func enterInForegroundMode(notification: NSNotification) {
        isBackgroundMode = false
        locationManager.stopUpdatingLocation()
    }
    
    
    //========================================================
    // MARK:- Start and Stop Tracking
    //========================================================
    func startTracking() -> Void {
        // isUpdate = true
        locationManager.startUpdatingLocation()
    }
    
    func startStatusLocTracking() -> Void {
        if statusTimer == nil {
            statusTimer = Timer.scheduledTimer(timeInterval: 30 , target: self, selector: #selector(statusTimerAction), userInfo: nil, repeats: true)
            locationManager.startUpdatingLocation()
        }
        
    }
    
    
    func stopTracking() -> Void {
        if timer != nil {
            timer?.invalidate()
            timer = nil
        }
        bgTask?.endAllBackgroundTasks()
        bgTask = nil
        
        locationManager.stopUpdatingLocation()
        isGPSenable = false
        
        self.removeNotificationCentreForlocation()
    }
    
    func stopStatusTracking() -> Void {
        if statusTimer != nil {
            statusTimer?.invalidate()
            statusTimer = nil
        }
        
        if isGPSenable == false {
            locationManager.stopUpdatingLocation()
        }
    }
    
    
    //========================================================
    // MARK:- Check if location is available
    //========================================================
    
    func isCheckLocation () -> Bool {
        if CLLocationManager.locationServicesEnabled() {
            switch CLLocationManager.authorizationStatus() {
            case .authorizedAlways, .authorizedWhenInUse:
                return true
            default :
                return false
            }
        }
        else {
            return false
        }
    }
    
    
    func isHaveLocation() {
        
        let isFirst =  UserDefaults.standard.value(forKey: "isFirstLogin") as! Bool
        
        if isFirst {
            UserDefaults.standard.set(false, forKey: "isFirstLogin")
        }else{
            return
        }
        
        if CLLocationManager.locationServicesEnabled() {
            
            switch CLLocationManager.authorizationStatus() {
            case .notDetermined, .restricted, .denied:
                
                let appName =  Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String   // [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleNameKey];
                
                let mess = AlertMessage.location_app_setting
                let newString = mess.replacingOccurrences(of: EOT_VAR, with: appName)
                
                
                ShowAlert(title: LanguageKey.location_is_disabled, message: newString, controller: windowController(), cancelButton: LanguageKey.settings as NSString, okButton: LanguageKey.ok as NSString, style: .alert, callback: { (settings,Okay) in
                    
                    if settings {
                        if let url = URL(string: UIApplication.openSettingsURLString) {
                            // If general location settings are enabled then open location settings for the app
                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
                        }
                    }
                } )
                
                // To enable location in EyeOnTask app setting
                //return false
                
                break
            default :
                print("Access")
                //locationManager.startUpdatingLocation()
                // return true
                break
            }
        } else {
            
            ShowAlert(title: LanguageKey.location_is_disabled, message: LanguageKey.location_main_setting, controller: windowController(), cancelButton: LanguageKey.ok as NSString, okButton: nil, style: .alert, callback: {(_ , _) in })
            isFirstLogin = false
            
            // return false
        }
    }
    
    
    func updateCurrentLocation(updateCallback : @escaping (Bool) -> Void) {
        callback = updateCallback
        locationManager.startUpdatingLocation()
    }
    
    
    //========================================================
    // MARK:- Other methods
    //========================================================
    @objc func timerAction() {
        isUpdate = true
        locationManager.startUpdatingLocation()
    }
    
    @objc func statusTimerAction() {
        isStatus = true
        locationManager.startUpdatingLocation()
    }
    
    
    func sendLocationOnServer(location : CLLocation) -> Void {
        let param = Params()
        param.usrId = getUserDetails()?.usrId
        param.lat = String(location.coordinate.latitude)
        param.lng = String(location.coordinate.longitude)
        param.btryStatus =  String(Int(UIDevice.current.batteryLevel*100))   // String(UIDevice.current.batteryLevel*100)
        param.dateTime =  CurrentDateTimeForLocation()
        Database.shared.saveOffline(service: Service.getLocationUpdate, param: param)
    }
    
    
    //========================================
    // MARK: - CoreLocation Delegate Methods
    //========================================
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        locationManager.stopUpdatingLocation()
        //print(error)
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if isStatus {
            isStatus = false
            let locationArray = locations as NSArray
            Currentloc = locationArray.lastObject as! CLLocation
            let coord = Currentloc.coordinate
            self.currentLattitude = String(coord.latitude)
            self.currentLongitude = String(coord.longitude)
            
            if self.callback != nil {
                self.callback!(true)
                self.callback = nil
            }
        }
        
        
        //DispatchQueue.main.async {
        if self.isUpdate {
            self.isUpdate =  false
            
            let locationArray = locations as NSArray
            self.Currentloc = locationArray.lastObject as! CLLocation
            let coord = self.Currentloc.coordinate
            self.currentLattitude = String(coord.latitude)
            self.currentLongitude = String(coord.longitude)
            
            
            if  self.isGPSenable == true  {
                self.bgTask =  BackgroundTaskManager.shared()
                self.bgTask?.beginNewBackgroundTask()
                
                if self.timer == nil{
                    
                    self.userDistance = 50
                    if let serverDistance = getDefaultSettings()?.trkDistance{
                        if serverDistance != "" {
                            self.userDistance = Int(serverDistance)!
                        }
                    }
                    
                    var trkDuration = "1"
                    if let serverDuration = getDefaultSettings()?.trkDuration{
                        if serverDuration != "" {
                            trkDuration = serverDuration
                        }
                    }
                    
                    //===================================================================================================================
                    //self.timer = Timer.scheduledTimer(timeInterval: Double(trkDuration)!*60 , target: self, selector: #selector(self.timerAction), userInfo: nil, repeats: true)
                    
                    
                    self.timer = Timer.scheduledTimer(timeInterval: 30 , target: self, selector: #selector(self.timerAction), userInfo: nil, repeats: true)
                   // print(timer)
                }
                
                let distance = self.Currentloc.distance(from: self.oldLocation)
                // print("Distance == \(distance)")
                //  print("Lat:\(coord.latitude) and Long:\(coord.longitude)")
                
                if (self.isGPSenable && Int(distance) > self.userDistance){
                    self.oldLocation = self.Currentloc
                    // ShowError(message: "location send successfully", controller: windowController())
                    
                    if locationHistory.count > 2 {
                        // let slice: ArraySlice<CLLocation> = locationHistory[locationHistory.endIndex-3..<locationHistory.endIndex]
                        let lastThree = locationHistory
                        
                        //var closestArray = [CLLocation]()
                        let distanceAtoB = lastThree[0].distance(from: lastThree[1])
                        let distanceAtoC = lastThree[0].distance(from: lastThree[2])
                        let distanceBtoC = lastThree[1].distance(from: lastThree[2])
                        
                        let distanceArray = [distanceAtoB,distanceAtoC,distanceBtoC]
                        
                        let closest = distanceArray.min(by:{ $0 < $1})
                        var twoLocations = [CLLocation]()
                        //closestArray.append(Currentloc)
                        if let index = distanceArray.firstIndex(of : closest!){
                            switch index {
                            case 0:
                                twoLocations.append(lastThree[0])
                                twoLocations.append(lastThree[1])
                            case 1:
                                twoLocations.append(lastThree[0])
                                twoLocations.append(lastThree[2])
                            case 2:
                                twoLocations.append(lastThree[1])
                                twoLocations.append(lastThree[2])
                            default:
                                print("No index found")
                            }
                        }
                       // print(closest!)
                        //let centerPoint = getCenterCoord(closestArray: twoLocations)
                        //centreLocation = centerPoint
                        locationHistory.removeAll()
                        //self.sendLocationOnServer(location: centreLocation)
                        self.sendLocationOnServer(location: twoLocations[0])
                        self.sendLocationOnServer(location: twoLocations[1])
                        
                        
                    }else{
                        locationHistory.append(Currentloc)
                        
                        if isFirstLocation == true{
                            isFirstLocation = false
                            self.sendLocationOnServer(location: Currentloc)
                        }
                    }
                    
                    
                }
            }
            
            if self.isBackgroundMode == false {
                self.locationManager.stopUpdatingLocation()
            }
            
        }
        // }
        
        //locationManager.stopUpdatingLocation()
    }
    
//    func getCenterCoord(closestArray: [CLLocation]) -> CLLocation{
//
//        var x:Float = 0.0
//        var y:Float = 0.0
//        var z:Float = 0.0
//
//        for points in closestArray {
//            let lat = GLKMathDegreesToRadians(Float(points.coordinate.latitude))
//            let long = GLKMathDegreesToRadians(Float(points.coordinate.longitude));
//
//            x += cos(lat) * cos(long);
//            y += cos(lat) * sin(long);
//            z += sin(lat);
//        }
//
//        x = x / Float(closestArray.count);
//        y = y / Float(closestArray.count);
//        z = z / Float(closestArray.count);
//
//        let resultLong = atan2(y, x);
//        let resultHyp = sqrt(x * x + y * y);
//        let resultLat = atan2(z, resultHyp);
//
//
//        let locationResult = CLLocation(latitude: CLLocationDegrees(GLKMathRadiansToDegrees(Float(resultLat))), longitude: CLLocationDegrees(GLKMathRadiansToDegrees(Float(resultLong))))
//
//
//        return locationResult;
//
//    }
//
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        
        // isLocation = false
        
        switch status {
        case .notDetermined:
            isPermissionAsked = true
            locationManager.requestAlwaysAuthorization()
            break
        case .authorizedWhenInUse:
            //    isLocation = true
            locationManager.startUpdatingLocation()
            break
        case .authorizedAlways:
            //   isLocation = true
            locationManager.startUpdatingLocation()
            break
        case .restricted:
            
            // restricted by e.g. parental controls. User can't enable Location Services
            break
        case .denied:
            // user denied your app access to Location Services, but can grant access from Settings.app
            break
        default:
            break
        }
    }
    
    

//    static let shared = LocationManager()
//    let locationManager = CLLocationManager()
//
//    var centreLocation = CLLocation()
//    var locationHistory = [CLLocation]()
//    var isUpdate = true
//   // var isLocation = Bool()
//    var Currentloc = CLLocation()
//    var oldLocation = CLLocation()
//
//    var currentLattitude : String = "0.0"
//    var currentLongitude : String = "0.0"
//    var isPermissionAsked = Bool()
//    var isFirstTime : Bool = true
//    var isStatus : Bool = false
//    var isFirstLogin : Bool = true
//    var  isGPSenable = false
//    var bgTask : BackgroundTaskManager?
//    var timer : Timer?
//    var statusTimer : Timer?
//    var userDistance : Int = 0
//    var isBackgroundMode = false
//
//    var callback: ((Bool) -> Void)?
//
//
//   private override init() {
//        super.init()
//
//            locationManager.delegate = self
//            locationManager.allowsBackgroundLocationUpdates = true
//            locationManager.pausesLocationUpdatesAutomatically = false
//          //  locationManager.desiredAccuracy = kCLLocationAccuracyBest
//          //  locationManager.distanceFilter = kCLDistanceFilterNone
//
//            if #available(iOS 11.0, *) {
//                locationManager.showsBackgroundLocationIndicator = true
//            } else {
//                // Fallback on earlier versions
//            }
//
//            locationManager.requestWhenInUseAuthorization()
//        // print("initialize Location Manager")
//    }
//
//
//    //========================================================
//    // MARK:- Notification Registration
//    //========================================================
//    func setNotificationCentreForlocation() -> Void {
//        NotificationCenter.default.addObserver(self, selector: #selector(self.enterInBackgroundMode(notification:)), name: UIApplication.didEnterBackgroundNotification, object: nil)
//
//        NotificationCenter.default.addObserver(self, selector: #selector(self.enterInForegroundMode(notification:)), name: UIApplication.willEnterForegroundNotification, object: nil)
//    }
//
//
//    func removeNotificationCentreForlocation() -> Void {
//           NotificationCenter.default.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
//           NotificationCenter.default.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
//    }
//
//
//    //========================================================
//    // MARK:- Background enter and Foreground method
//    //========================================================
//    @objc func enterInBackgroundMode(notification: NSNotification) {
//        isUpdate = true
//        isBackgroundMode = true
//        locationManager.startUpdatingLocation()
//    }
//
//    @objc func enterInForegroundMode(notification: NSNotification) {
//         isBackgroundMode = false
//         locationManager.stopUpdatingLocation()
//    }
//
//
//    //========================================================
//    // MARK:- Start and Stop Tracking
//    //========================================================
//    func startTracking() -> Void {
//          // isUpdate = true
//           locationManager.startUpdatingLocation()
//    }
//
//    func startStatusLocTracking() -> Void {
//        if statusTimer == nil {
//            statusTimer = Timer.scheduledTimer(timeInterval: 30 , target: self, selector: #selector(statusTimerAction), userInfo: nil, repeats: true)
//             locationManager.startUpdatingLocation()
//        }
//
//    }
//
//
//    func stopTracking() -> Void {
//        if timer != nil {
//            timer?.invalidate()
//            timer = nil
//        }
//        bgTask?.endAllBackgroundTasks()
//        bgTask = nil
//
//        locationManager.stopUpdatingLocation()
//         isGPSenable = false
//
//        self.removeNotificationCentreForlocation()
//    }
//
//    func stopStatusTracking() -> Void {
//        if statusTimer != nil {
//            statusTimer?.invalidate()
//            statusTimer = nil
//        }
//
//        if isGPSenable == false {
//             locationManager.stopUpdatingLocation()
//        }
//    }
//
//
//    //========================================================
//    // MARK:- Check if location is available
//    //========================================================
//
//    func isCheckLocation () -> Bool {
//        if CLLocationManager.locationServicesEnabled() {
//            switch CLLocationManager.authorizationStatus() {
//                    case .authorizedAlways, .authorizedWhenInUse:
//                        return true
//                    default :
//                        return false
//            }
//        }
//        else {
//                return false
//           }
//    }
//
//
//    func isHaveLocation() {
//
//        let isFirst =  UserDefaults.standard.value(forKey: "isFirstLogin") as! Bool
//
//        if isFirst {
//            UserDefaults.standard.set(false, forKey: "isFirstLogin")
//        }else{
//            return
//        }
//
//         if CLLocationManager.locationServicesEnabled() {
//
//            switch CLLocationManager.authorizationStatus() {
//            case .notDetermined, .restricted, .denied:
//
//                let appName =  Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String   // [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleNameKey];
//
//                let mess = AlertMessage.location_app_setting
//                let newString = mess.replacingOccurrences(of: EOT_VAR, with: appName)
//
//
//                ShowAlert(title: LanguageKey.location_is_disabled, message: newString, controller: windowController(), cancelButton: LanguageKey.settings as NSString, okButton: LanguageKey.ok as NSString, style: .alert, callback: { (settings,Okay) in
//
//                    if settings {
//                        if let url = URL(string: UIApplication.openSettingsURLString) {
//                            // If general location settings are enabled then open location settings for the app
//                            UIApplication.shared.open(url, options: [:], completionHandler: nil)
//                        }
//                    }
//                } )
//
//                // To enable location in EyeOnTask app setting
//                //return false
//
//                break
//            default :
//                print("Access")
//                //locationManager.startUpdatingLocation()
//               // return true
//                break
//            }
//        } else {
//
//            ShowAlert(title: LanguageKey.location_is_disabled, message: LanguageKey.location_main_setting, controller: windowController(), cancelButton: LanguageKey.ok as NSString, okButton: nil, style: .alert, callback: {(_ , _) in })
//                 isFirstLogin = false
//
//           // return false
//        }
//    }
//
//
//    func updateCurrentLocation(updateCallback : @escaping (Bool) -> Void) {
//        callback = updateCallback
//        locationManager.startUpdatingLocation()
//    }
//
//
//    //========================================================
//    // MARK:- Other methods
//    //========================================================
//    @objc func timerAction() {
//        isUpdate = true
//        locationManager.startUpdatingLocation()
//    }
//
//    @objc func statusTimerAction() {
//        isStatus = true
//        locationManager.startUpdatingLocation()
//    }
//
//
//    func sendLocationOnServer() -> Void {
//        let param = Params()
//        param.usrId = getUserDetails()?.usrId
//        param.lat = currentLattitude
//        param.lng = currentLongitude
//        param.btryStatus =  String(Int(UIDevice.current.batteryLevel*100))   // String(UIDevice.current.batteryLevel*100)
//        param.dateTime =  CurrentDateTimeForLocation()
//        Database.shared.saveOffline(service: Service.getLocationUpdate, param: param)
//    }
//
//
//    //========================================
//    // MARK: - CoreLocation Delegate Methods
//    //========================================
//    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
//        locationManager.stopUpdatingLocation()
//        //print(error)
//    }
//
//
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//
//        if isStatus {
//            isStatus = false
//            let locationArray = locations as NSArray
//            Currentloc = locationArray.lastObject as! CLLocation
//            let coord = Currentloc.coordinate
//            self.currentLattitude = String(coord.latitude)
//            self.currentLongitude = String(coord.longitude)
//
//            if self.callback != nil {
//                self.callback!(true)
//                self.callback = nil
//            }
//        }
//
//
//        //DispatchQueue.main.async {
//            if self.isUpdate {
//                self.isUpdate =  false
//
//                let locationArray = locations as NSArray
//                self.Currentloc = locationArray.lastObject as! CLLocation
//                let coord = self.Currentloc.coordinate
//                self.currentLattitude = String(coord.latitude)
//                self.currentLongitude = String(coord.longitude)
//
//
//                if  self.isGPSenable == true  {
//                    self.bgTask =  BackgroundTaskManager.shared()
//                    self.bgTask?.beginNewBackgroundTask()
//
//                    if self.timer == nil{
//
//                        self.userDistance = 100
//                        if let serverDistance = getDefaultSettings()?.trkDistance{
//                            if serverDistance != "" {
//                                self.userDistance = Int(serverDistance)!
//                            }
//                        }
//
//                        var trkDuration = "1"
//                        if let serverDuration = getDefaultSettings()?.trkDuration{
//                            if serverDuration != "" {
//                                trkDuration = serverDuration
//                            }
//                        }
//
//
//                        //self.timer = Timer.scheduledTimer(timeInterval: Double(trkDuration)!*60 , target: self, selector: #selector(self.timerAction), userInfo: nil, repeats: true)
//
//
//                        self.timer = Timer.scheduledTimer(timeInterval: 30 , target: self, selector: #selector(self.timerAction), userInfo: nil, repeats: true)
//                    }
//
//                    let distance = self.Currentloc.distance(from: self.oldLocation)
//                    // print("Distance == \(distance)")
//                    //  print("Lat:\(coord.latitude) and Long:\(coord.longitude)")
//
//                    if (self.isGPSenable && Int(distance) > self.userDistance){
//                        self.oldLocation = self.Currentloc
//                        // ShowError(message: "location send successfully", controller: windowController())
//
//
//                        if locationHistory.count > 2 {
//                            // let slice: ArraySlice<CLLocation> = locationHistory[locationHistory.endIndex-3..<locationHistory.endIndex]
//                            let lastThree = locationHistory
//
//                            //var closestArray = [CLLocation]()
//                            let distanceAtoB = lastThree[0].distance(from: lastThree[1])
//                            let distanceAtoC = lastThree[0].distance(from: lastThree[2])
//                            let distanceBtoC = lastThree[1].distance(from: lastThree[2])
//
//                            let distanceArray = [distanceAtoB,distanceAtoC,distanceBtoC]
//
//                            let closest = distanceArray.min(by:{ $0 < $1})
//                            var twoLocations = [CLLocation]()
//                            //closestArray.append(Currentloc)
//                            if let index = distanceArray.firstIndex(of : closest!){
//                                switch index {
//                                case 0:
//                                    twoLocations.append(lastThree[0])
//                                    twoLocations.append(lastThree[1])
//                                case 1:
//                                    twoLocations.append(lastThree[0])
//                                    twoLocations.append(lastThree[2])
//                                case 2:
//                                    twoLocations.append(lastThree[1])
//                                    twoLocations.append(lastThree[2])
//                                default:
//                                    print("No index found")
//                                }
//                            }
//                            print(closest!)
//                            let centerPoint = getCenterCoord(closestArray: twoLocations)
//
//                            centreLocation = centerPoint
//                            locationHistory.removeAll()
//                            self.sendLocationOnServer()
//
//                        }else{
//                            locationHistory.append(Currentloc)
//                        }
//
//
//                    }
//                }
//
//                if self.isBackgroundMode == false {
//                    self.locationManager.stopUpdatingLocation()
//                }
//
//            }
//       // }
//
//
//        //locationManager.stopUpdatingLocation()
//    }
//
//    func getCenterCoord(closestArray: [CLLocation]) -> CLLocation{
//
//        var x:Float = 0.0
//        var y:Float = 0.0
//        var z:Float = 0.0
//
//        for points in closestArray {
//            let lat = GLKMathDegreesToRadians(Float(points.coordinate.latitude))
//            let long = GLKMathDegreesToRadians(Float(points.coordinate.longitude));
//
//            x += cos(lat) * cos(long);
//            y += cos(lat) * sin(long);
//            z += sin(lat);
//        }
//
//        x = x / Float(closestArray.count);
//        y = y / Float(closestArray.count);
//        z = z / Float(closestArray.count);
//
//        let resultLong = atan2(y, x);
//        let resultHyp = sqrt(x * x + y * y);
//        let resultLat = atan2(z, resultHyp);
//
//
//        let locationResult = CLLocation(latitude: CLLocationDegrees(GLKMathRadiansToDegrees(Float(resultLat))), longitude: CLLocationDegrees(GLKMathRadiansToDegrees(Float(resultLong))))
//
//
//        return locationResult;
//
//    }
//
//
//    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
//
//       // isLocation = false
//
//        switch status {
//        case .notDetermined:
//            isPermissionAsked = true
//            locationManager.requestAlwaysAuthorization()
//            break
//        case .authorizedWhenInUse:
//        //    isLocation = true
//            locationManager.startUpdatingLocation()
//            break
//        case .authorizedAlways:
//         //   isLocation = true
//            locationManager.startUpdatingLocation()
//            break
//        case .restricted:
//
//            // restricted by e.g. parental controls. User can't enable Location Services
//            break
//        case .denied:
//            // user denied your app access to Location Services, but can grant access from Settings.app
//            break
//        default:
//            break
//        }
//    }
//
}
    

